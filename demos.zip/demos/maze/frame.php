<html>
<head>
  <meta charset="utf-8">
  <title>Blockly Demo: Maze</title>
  <script type="text/javascript" src="../blockly_compressed.js"></script>
  <script type="text/javascript" src="../../generators/javascript.js"></script>
  <script type="text/javascript" src="../../generators/javascript/control.js"></script>
  <script type="text/javascript" src="../../generators/javascript/logic.js"></script>
  <script type="text/javascript" src="en-language.js"></script>
  <script type="text/javascript" src="../../language/en/_messages.js"></script>
  <script type="text/javascript" src="../../language/en/control.js"></script>
  <script type="text/javascript" src="../../language/en/logic.js"></script>

  <style>
    html, body {
      background-color: #fff;
      margin: 0;
      padding:0;
      overflow: hidden;
    }
    .blocklySvg {
      height: 100%;
      width: 100%;
    }
  </style>
  <script>
    function init() {
      // Whitelist of blocks to keep.
      var newLanguage = {};
      var keepers = ['maze_move', 'maze_turnLeft', 'maze_turnRight',
          'maze_isWall', 'controls_if', 'controls_if_if', 'controls_if_elseif',
          'controls_if_else', 'controls_forever', 'controls_whileUntil',
          'logic_operation', 'logic_negate'];
      for (var x = 0; x < keepers.length; x++) {
        newLanguage[keepers[x]] = Blockly.Language[keepers[x]];
      }
      
      // Fold control category into logic category.
      for (var name in newLanguage) {
        if (newLanguage[name].category == 'Control') {
          newLanguage[name].category = 'Logic';
        }
      }
      Blockly.Language = newLanguage;

      Blockly.inject(document.body, {path: '../../'});
      
      if (window.parent.Maze) {
        // Let the top-level application know that Blockly is ready.
        
        window.parent.Maze.init(Blockly);
        window.parent.jalan.init();
      } else {
        // Attempt to diagnose the problem.
        var msg = 'Error: Unable to communicate between frames.\n\n';
        if (window.parent == window) {
          msg += 'Try loading index.php instead of frame.php';
        } else if (window.location.protocol == 'file:') {
          msg += 'This may be due to a security restriction preventing\n' +
              'access when using the file:// protocol.\n' +
              'http://code.google.com/p/chromium/issues/detail?id=47416';
        }
        alert(msg);
      }
    }
  </script>
</head>
<body onload="init()">
</body>
</html>
